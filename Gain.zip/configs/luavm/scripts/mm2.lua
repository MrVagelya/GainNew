local plrs = game:GetService("Players")
local run = game:GetService("RunService")
local ws = game:GetService("Workspace")

local me = plrs.LocalPlayer.Name

local knifeClr = Color3.fromRGB(255, 50, 50)
local gunClr = Color3.fromRGB(50, 100, 255)
local safeClr = Color3.fromRGB(50, 255, 50)
local goldClr = Color3.fromRGB(255, 200, 0)
local whiteClr = Color3.fromRGB(255, 255, 255)
local greyClr = Color3.fromRGB(180, 180, 180)
local charH = 5.0

local esps = {}
local drops = {}

local function newLine(col)
	local l = Drawing.new("Line")
	l.Thickness = 1
	l.Color = col
	l.Visible = false
	return l
end

local function newText(col)
	local t = Drawing.new("Text")
	t.Font = Drawing.Fonts.System
	t.Color = col
	t.Outline = true
	t.Center = true
	t.Visible = false
	return t
end

local function newBox(col)
	return { newLine(col), newLine(col), newLine(col), newLine(col) }
end

local function setBox(box, L, R, T, B)
	box[1].From = Vector2.new(L, T) ; box[1].To = Vector2.new(R, T)
	box[2].From = Vector2.new(L, B) ; box[2].To = Vector2.new(R, B)
	box[3].From = Vector2.new(L, T) ; box[3].To = Vector2.new(L, B)
	box[4].From = Vector2.new(R, T) ; box[4].To = Vector2.new(R, B)
end

local function colorBox(box, col)
	for _, l in ipairs(box) do l.Color = col end
end

local function showBox(box, v)
	for _, l in ipairs(box) do l.Visible = v end
end

local function addEsp(plr)
	esps[plr] = {
		box = newBox(safeClr),
		name = newText(safeClr),
		dist = newText(greyClr),
		cache = { root = nil, hum = nil, col = safeClr, role = "Innocent" }
	}
end

local function removeEsp(plr)
	local e = esps[plr]
	if not e then return end
	showBox(e.box, false)
	for _, l in ipairs(e.box) do l:Remove() end
	e.name:Remove()
	e.dist:Remove()
	esps[plr] = nil
end

local function showEsp(e, v)
	showBox(e.box, v)
	e.name.Visible = v
	e.dist.Visible = v
end

local function getRole(plr, chr)
	local bp = plr:FindFirstChildOfClass("Backpack")
	local function got(c, n) return c and c:FindFirstChild(n) ~= nil end
	if got(bp, "Knife") or got(chr, "Knife") then
		return knifeClr, "Murderer"
	elseif got(bp, "Gun") or got(chr, "Gun") then
		return gunClr, "Sheriff"
	end
	return safeClr, "Innocent"
end

local function refreshCache(plr, e)
	local chr = plr.Character
	local hum = chr and chr:FindFirstChildOfClass("Humanoid")
	local root = chr and chr.PrimaryPart
	local col, role
	if chr then
		col, role = getRole(plr, chr)
	else
		col, role = safeClr, "Innocent"
	end
	e.cache = { root = root, hum = hum, col = col, role = role }
end

local function addDrop(part)
	drops[part] = {
		box = newBox(goldClr),
		lbl = newText(goldClr)
	}
	drops[part].lbl.Text = "GUN DROP"
end

local function removeDrop(part)
	local d = drops[part]
	if not d then return end
	for _, l in ipairs(d.box) do l:Remove() end
	d.lbl:Remove()
	drops[part] = nil
end

local function showDrop(d, v)
	showBox(d.box, v)
	d.lbl.Visible = v
end

local scanCo = nil
local scanT = 0

local function doScan()
	local found = {}
	local all = ws:GetDescendants()
	coroutine.yield()
	for i = 1, #all do
		local obj = all[i]
		if obj.Name == "GunDrop" and obj:IsA("BasePart") then
			found[obj] = true
			if not drops[obj] then addDrop(obj) end
		end
		if i % 150 == 0 then coroutine.yield() end
	end
	for part in pairs(drops) do
		if not found[part] then removeDrop(part) end
	end
end

local plrT = 0
local cacheT = 0

run.RenderStepped:Connect(function(dt)
	local cam = ws.CurrentCamera
	local camPos = cam and cam.Position

	plrT += dt
	if plrT >= 1 then
		plrT = 0
		local alive = {}
		for _, p in ipairs(plrs:GetPlayers()) do
			if p.Name ~= me then
				alive[p] = true
				if not esps[p] then addEsp(p) end
			end
		end
		for p in pairs(esps) do
			if not alive[p] then removeEsp(p) end
		end
	end

	cacheT += dt
	if cacheT >= 0.5 then
		cacheT = 0
		for p, e in pairs(esps) do
			refreshCache(p, e)
		end
	end

	scanT += dt
	if scanT >= 5 and not scanCo then
		scanT = 0
		scanCo = coroutine.create(doScan)
	end
	if scanCo then
		coroutine.resume(scanCo)
		if coroutine.status(scanCo) == "dead" then scanCo = nil end
	end

	for plr, e in pairs(esps) do
		local c = e.cache
		if not (c.root and c.root.Parent and c.hum and c.hum.Health > 0 and camPos) then
			showEsp(e, false)
			continue
		end

		local rp = c.root.Position
		local top2d, onTop = WorldToScreen(Vector3.new(rp.X, rp.Y + charH * 0.5, rp.Z))
		local bot2d, onBot = WorldToScreen(Vector3.new(rp.X, rp.Y - charH * 0.5, rp.Z))
		if not (onTop and onBot) then showEsp(e, false) continue end

		local h = math.abs(bot2d.Y - top2d.Y)
		local w = h * 0.5
		local cx = top2d.X
		local L = cx - w * 0.5
		local R = cx + w * 0.5
		local T = top2d.Y
		local B = bot2d.Y

		colorBox(e.box, c.col)
		setBox(e.box, L, R, T, B)

		e.name.Color = c.col
		e.name.Text = c.role .. " | " .. plr.Name
		e.name.Position = Vector2.new(cx, T - 16)
		e.dist.Text = math.floor((camPos - rp).Magnitude) .. "m"
		e.dist.Position = Vector2.new(cx, B + 3)
		showEsp(e, true)
	end

	for part, d in pairs(drops) do
		local p2d, vis = WorldToScreen(part.Position)
		if not vis then showDrop(d, false) continue end

		local s = 16
		setBox(d.box, p2d.X - s, p2d.X + s, p2d.Y - s, p2d.Y + s)
		d.lbl.Position = Vector2.new(p2d.X, p2d.Y - s - 14)
		showDrop(d, true)
	end
end)

notify("ESP", "Loaded", 3)
-- ==============================================================================
-- KOMARU STEP (Matcha LuaVM)
-- Features:
--   - FIX: Reliable input detection (setrobloxinput(true), foreground check, clean state tracking)
--   - Movement Tab:
--       * Slot 1-4 move boost tuning (Multiplier, Boost After, Boost For)
--       * Sub-Section: Dash (Q) Boost (Direct Velocity Speed, Boost After, Boost For, Air-Only toggle)
--       * Sub-Section: Jump (Space) Boost (Vertical / Jump velocity multiplier)
--       * Air-Only filter
--   - Soru (R) Spam is permanently Always Active
--   - Move After Soru (Proximity Trigger within window)
--   - Auto-reset slot to 0 on death or respawn
--   - Direct tab scrolling with Mouse Wheel or Arrow Keys / PageUp / PageDown
--   - Full Save / Load Config manager (JSON under MatchaMacros/KomaruStep)
-- ==============================================================================

-- Enable Matcha input injection to Roblox engine
pcall(function()
    setrobloxinput(true)
end)

local Players = game:GetService("Players")

-- Load Enhanced Wabi Sabi UI Library (with mouse wheel & arrow scrolling support)
local ok, libCode = pcall(function()
    if isfile and isfile("wabi_sabi_ui_lib_scroll.lua") then
        return readfile("wabi_sabi_ui_lib_scroll.lua")
    end
    return nil
end)

if ok and libCode then
    loadstring(libCode)()
else
    loadstring(game:HttpGet("https://scripts.wabisabi.mom/wabi-sabi-ui-lib.lua"))()
end

local Library = WabiSabi

-- Configure config save folder
Library:SetFolder("MatchaMacros/KomaruStep")

-- Windows Virtual-Key Codes
local VK = {
    Z = 0x5A, X = 0x58, C = 0x43, V = 0x56, F = 0x46, R = 0x52, Q = 0x51, SPACE = 0x20,
    ["1"] = 0x31, ["2"] = 0x32, ["3"] = 0x33, ["4"] = 0x34,
    F1 = 0x70, F2 = 0x71,
}

local KeyNameToVK = {
    Z = 0x5A, X = 0x58, C = 0x43, V = 0x56, F = 0x46,
    Q = 0x51, E = 0x45, T = 0x54, G = 0x47, B = 0x42,
    ["1"] = 0x31, ["2"] = 0x32, ["3"] = 0x33, ["4"] = 0x34,
}

-- Macro Configuration
local Config = {
    Enabled = true,
    CurrentSlot = 0,
    ReleaseDelay = 15,
    AutoReleaseHoldTime = 20,

    -- Preset configurations per slot
    Slots = {
        [1] = {
            CanUnequip = true,
            Mode = "Spam",
            Keys = { z = true, x = true, c = true, v = false, f = false },
            MoveAfterSoru = {
                Enabled = true,
                FollowUpKey = "Z",
                WindowMs = 200,
                TriggerDistance = 15,
            }
        },
        [2] = {
            CanUnequip = false,
            Mode = "Spam",
            Keys = { z = true, x = true, c = true, v = true, f = true },
            MoveAfterSoru = {
                Enabled = true,
                FollowUpKey = "X",
                WindowMs = 200,
                TriggerDistance = 15,
            }
        },
        [3] = {
            CanUnequip = false,
            Mode = "Spam",
            Keys = { z = true, x = true, c = false, v = false, f = false },
            MoveAfterSoru = {
                Enabled = true,
                FollowUpKey = "Z",
                WindowMs = 200,
                TriggerDistance = 15,
            }
        },
        [4] = {
            CanUnequip = true,
            Mode = "Spam",
            Keys = { z = true, x = true, c = false, v = false, f = false },
            MoveAfterSoru = {
                Enabled = true,
                FollowUpKey = "Z",
                WindowMs = 200,
                TriggerDistance = 15,
            }
        },
    },

    -- Movement Settings
    Movement = {
        Enabled = true,
        AirOnly = true, -- Does NOT work on the ground
        -- Per slot move velocity boosts
        Slots = {
            [1] = {
                Enabled = true,
                Multiplier = 1.5,
                BoostAfterMs = 40,
                BoostForMs = 120,
                Cooldown = 5.0, -- Minimum 5 second delay between slot boosts
                Moves = { z = true, x = true, c = true, v = false, f = false }
            },
            [2] = {
                Enabled = true,
                Multiplier = 1.5,
                BoostAfterMs = 40,
                BoostForMs = 120,
                Cooldown = 5.0,
                Moves = { z = true, x = true, c = true, v = true, f = true }
            },
            [3] = {
                Enabled = true,
                Multiplier = 1.5,
                BoostAfterMs = 40,
                BoostForMs = 120,
                Cooldown = 5.0,
                Moves = { z = true, x = true, c = false, v = false, f = false }
            },
            [4] = {
                Enabled = true,
                Multiplier = 1.5,
                BoostAfterMs = 40,
                BoostForMs = 120,
                Cooldown = 5.0,
                Moves = { z = true, x = true, c = false, v = false, f = false }
            },
        },
        -- Dash (Q) Boost
        Dash = {
            Enabled = true,
            Speed = 120,
            BoostAfterMs = 20,
            BoostForMs = 150,
            AirOnly = false,
        },
        -- Jump (Space) Boost
        Jump = {
            Enabled = true,
            Multiplier = 1.5,
            BoostAfterMs = 20,
            BoostForMs = 120,
        }
    },

    -- Soru (R) settings
    Soru = {
        Enabled = true,
        Delay = 15,
    },

    -- Move After Soru settings
    MoveAfterSoru = {
        Enabled = true,
        FollowUpKey = "Z",
        WindowMs = 200,
        TriggerDistance = 15,
        CooldownMs = 400,
    }
}

-- State tracking
local ActiveMoveThreads = {}
local MoveBoostCooldown = { z = 0, x = 0, c = 0, v = 0, f = 0, q = 0, space = 0 }
local PhysicalHeld = {
    z = false, x = false, c = false, v = false, f = false, r = false, q = false, space = false,
    ["1"] = false, ["2"] = false, ["3"] = false, ["4"] = false,
    F1 = false, F2 = false
}

local function notify(title, msg, dur)
    pcall(function()
        Library:Notify({ Title = title, Content = msg, Duration = dur or 2 })
    end)
end

-- ==============================================================================
-- GUI SETUP
-- ==============================================================================
local Window = Library:CreateWindow({
    Title = "Komaru Step",
    SubTitle = "v2.0",
    Size = Vector2.new(620, 520),
    Resize = true,
    Theme = "Vynixu",
    Translucent = true,
    MinimizeKey = "F3"
})

-- 1. Main Tab
local MainTab = Window:AddTab({ Title = "Main", Icon = "sliders-horizontal" })
local StatusSection = MainTab:AddSection("Status")

local ToggleMain = StatusSection:AddToggle({
    Id = "macro_enabled",
    Title = "Macro Active (F1)",
    Description = "Master toggle",
    Default = true,
    Keybind = "F1",
    Callback = function(val)
        Config.Enabled = val
        notify("Macro", val and "ENABLED" or "DISABLED", 1.5)
    end
})

local SlotDropdown = StatusSection:AddDropdown({
    Id = "current_slot",
    Title = "Active Slot",
    Description = "Synced or manual select",
    Values = { "None (Unequipped)", "Slot 1", "Slot 2", "Slot 3", "Slot 4" },
    Default = "None (Unequipped)",
    Callback = function(val)
        if val == "Slot 1" then Config.CurrentSlot = 1
        elseif val == "Slot 2" then Config.CurrentSlot = 2
        elseif val == "Slot 3" then Config.CurrentSlot = 3
        elseif val == "Slot 4" then Config.CurrentSlot = 4
        else Config.CurrentSlot = 0 end
    end
})

local function syncSlotUI(slotNum)
    local names = { [0] = "None (Unequipped)", [1] = "Slot 1", [2] = "Slot 2", [3] = "Slot 3", [4] = "Slot 4" }
    pcall(function()
        SlotDropdown:SetValue(names[slotNum] or "None (Unequipped)")
    end)
end

StatusSection:AddButton({
    Title = "Reset to None (F2)",
    Description = "Clear slot tracking",
    Callback = function()
        Config.CurrentSlot = 0
        syncSlotUI(0)
        notify("Reset", "Slot set to None", 1.5)
    end
})

local TimingSection = MainTab:AddSection("Timings")

TimingSection:AddSlider({
    Id = "spam_delay",
    Title = "Spam Delay (ms)",
    Description = "Loop speed",
    Min = 5,
    Max = 100,
    Default = Config.ReleaseDelay,
    Rounding = 0,
    Callback = function(val) Config.ReleaseDelay = val end
})

TimingSection:AddSlider({
    Id = "auto_release_hold",
    Title = "Auto-Release Hold (ms)",
    Description = "Tap hold duration",
    Min = 5,
    Max = 150,
    Default = Config.AutoReleaseHoldTime,
    Rounding = 0,
    Callback = function(val) Config.AutoReleaseHoldTime = val end
})

-- 2. Movement Tab (Global, Dash Q, Jump Space & Per-Slot)
local MoveTab = Window:AddTab({ Title = "Movement", Icon = "wind" })
local MoveGlobalSec = MoveTab:AddSection("Global Movement")

MoveGlobalSec:AddToggle({
    Id = "mov_enabled",
    Title = "Velocity Boost",
    Description = "Master velocity boost toggle",
    Default = Config.Movement.Enabled,
    Callback = function(val) Config.Movement.Enabled = val end
})

MoveGlobalSec:AddToggle({
    Id = "mov_air_only",
    Title = "Air Only (No Ground)",
    Description = "Does not work when standing on the ground",
    Default = Config.Movement.AirOnly,
    Callback = function(val) Config.Movement.AirOnly = val end
})

-- Dash (Q) Sub-Section
local DashSec = MoveTab:AddSection("Dash (Q) Boost")

DashSec:AddToggle({
    Id = "mov_dash_enabled",
    Title = "Enable Dash (Q) Boost",
    Description = "Set velocity after pressing Q",
    Default = Config.Movement.Dash.Enabled,
    Callback = function(val) Config.Movement.Dash.Enabled = val end
})

DashSec:AddSlider({
    Id = "mov_dash_speed",
    Title = "Dash Velocity",
    Description = "Velocity magnitude to set",
    Min = 20,
    Max = 350,
    Default = Config.Movement.Dash.Speed,
    Rounding = 0,
    Callback = function(val) Config.Movement.Dash.Speed = val end
})

DashSec:AddSlider({
    Id = "mov_dash_after",
    Title = "Dash Boost After (ms)",
    Description = "Delay before dash kicks in",
    Min = 0,
    Max = 500,
    Default = Config.Movement.Dash.BoostAfterMs,
    Rounding = 0,
    Callback = function(val) Config.Movement.Dash.BoostAfterMs = val end
})

DashSec:AddSlider({
    Id = "mov_dash_for",
    Title = "Dash Boost For (ms)",
    Description = "Dash duration (max 1000ms / 1s)",
    Min = 50,
    Max = 1000,
    Default = Config.Movement.Dash.BoostForMs,
    Rounding = 0,
    Callback = function(val) Config.Movement.Dash.BoostForMs = math.min(1000, val) end
})

DashSec:AddToggle({
    Id = "mov_dash_aironly",
    Title = "Dash Air Only",
    Description = "Only dash while airborne",
    Default = Config.Movement.Dash.AirOnly,
    Callback = function(val) Config.Movement.Dash.AirOnly = val end
})

-- Jump (Space) Sub-Section
local JumpSec = MoveTab:AddSection("Jump (Space) Boost")

JumpSec:AddToggle({
    Id = "mov_jump_enabled",
    Title = "Enable Jump Boost",
    Description = "Boost jump velocity after pressing Space",
    Default = Config.Movement.Jump.Enabled,
    Callback = function(val) Config.Movement.Jump.Enabled = val end
})

JumpSec:AddSlider({
    Id = "mov_jump_mult",
    Title = "Jump Multiplier (x)",
    Description = "Jump boost factor (0.5x - 3.0x)",
    Min = 0.5,
    Max = 3.0,
    Default = Config.Movement.Jump.Multiplier,
    Rounding = 2,
    Callback = function(val) Config.Movement.Jump.Multiplier = val end
})

JumpSec:AddSlider({
    Id = "mov_jump_after",
    Title = "Jump Boost After (ms)",
    Description = "Delay before jump boost kicks in",
    Min = 0,
    Max = 500,
    Default = Config.Movement.Jump.BoostAfterMs,
    Rounding = 0,
    Callback = function(val) Config.Movement.Jump.BoostAfterMs = val end
})

JumpSec:AddSlider({
    Id = "mov_jump_for",
    Title = "Jump Boost For (ms)",
    Description = "Jump duration (max 1000ms / 1s)",
    Min = 50,
    Max = 1000,
    Default = Config.Movement.Jump.BoostForMs,
    Rounding = 0,
    Callback = function(val) Config.Movement.Jump.BoostForMs = math.min(1000, val) end
})

-- Individual Slot Settings (Slots 1 to 4)
for slotNum = 1, 4 do
    local sCfg = Config.Movement.Slots[slotNum]
    local slotSec = MoveTab:AddSection("Slot " .. slotNum .. " Move Boosts")

    slotSec:AddToggle({
        Id = "mov_s" .. slotNum .. "_enable",
        Title = "Enable Slot " .. slotNum .. " Boost",
        Description = "Apply velocity boost to Slot " .. slotNum,
        Default = sCfg.Enabled,
        Callback = function(val) sCfg.Enabled = val end
    })

    slotSec:AddSlider({
        Id = "mov_s" .. slotNum .. "_mult",
        Title = "Multiplier (x)",
        Description = "Boost factor (0.5x - 3.0x)",
        Min = 0.5,
        Max = 3.0,
        Default = sCfg.Multiplier,
        Rounding = 2,
        Callback = function(val) sCfg.Multiplier = val end
    })

    slotSec:AddSlider({
        Id = "mov_s" .. slotNum .. "_after",
        Title = "Boost After (ms)",
        Description = "Delay before boost kicks in",
        Min = 0,
        Max = 500,
        Default = sCfg.BoostAfterMs,
        Rounding = 0,
        Callback = function(val) sCfg.BoostAfterMs = val end
    })

    slotSec:AddSlider({
        Id = "mov_s" .. slotNum .. "_for",
        Title = "Boost For (ms)",
        Description = "Duration (max 1000ms / 1s)",
        Min = 50,
        Max = 1000,
        Default = sCfg.BoostForMs,
        Rounding = 0,
        Callback = function(val) sCfg.BoostForMs = math.min(1000, val) end
    })

    slotSec:AddSlider({
        Id = "mov_s" .. slotNum .. "_cd",
        Title = "Cooldown Between Boosts (s)",
        Description = "Min delay between boosts (>= 5s)",
        Min = 5,
        Max = 30,
        Default = math.max(5, sCfg.Cooldown or 5),
        Rounding = 1,
        Callback = function(val) sCfg.Cooldown = math.max(5, val) end
    })

    for _, key in ipairs({ "z", "x", "c", "v", "f" }) do
        slotSec:AddToggle({
            Id = "mov_s" .. slotNum .. "_" .. key,
            Title = string.upper(key) .. " Boosts Velocity",
            Description = "Slot " .. slotNum .. " " .. string.upper(key),
            Default = sCfg.Moves[key],
            Callback = function(val) sCfg.Moves[key] = val end
        })
    end
end

-- 3. Slot Tabs 1 to 4
local function setupSlotTab(slotNum, name, icon)
    local tab = Window:AddTab({ Title = name, Icon = icon })
    local sec = tab:AddSection("Slot Settings")
    local cfg = Config.Slots[slotNum]

    sec:AddDropdown({
        Id = "slot_" .. slotNum .. "_mode",
        Title = "Execution Mode",
        Description = "Spam or Auto-Release",
        Values = { "Spam", "Auto-Release" },
        Default = cfg.Mode,
        Callback = function(val) cfg.Mode = val end
    })

    sec:AddToggle({
        Id = "slot_" .. slotNum .. "_unequip",
        Title = "Unequip on Re-press",
        Description = "Re-press unequips",
        Default = cfg.CanUnequip,
        Callback = function(val) cfg.CanUnequip = val end
    })

    local moveSec = tab:AddSection("Keys Active")
    for _, key in ipairs({ "z", "x", "c", "v", "f" }) do
        moveSec:AddToggle({
            Id = "slot_" .. slotNum .. "_" .. key,
            Title = string.upper(key) .. " Move",
            Description = "Enable for " .. string.upper(key),
            Default = cfg.Keys[key],
            Callback = function(val) cfg.Keys[key] = val end
        })
    end

    local autoMoveSec = tab:AddSection("Auto Soru Follow-up")
    local smCfg = cfg.MoveAfterSoru
    if not smCfg then
        smCfg = { Enabled = true, FollowUpKey = "Z", WindowMs = 200, TriggerDistance = 15 }
        cfg.MoveAfterSoru = smCfg
    end

    autoMoveSec:AddToggle({
        Id = "slot_" .. slotNum .. "_soru_followup_enabled",
        Title = "Enable Soru Follow-up",
        Description = "Auto-fire move on proximity after Soru",
        Default = smCfg.Enabled,
        Callback = function(val) smCfg.Enabled = val end
    })

    autoMoveSec:AddDropdown({
        Id = "slot_" .. slotNum .. "_soru_followup_key",
        Title = "Follow-up Key",
        Description = "Move to cast for Slot " .. slotNum,
        Values = { "Z", "X", "C", "V", "F" },
        Default = smCfg.FollowUpKey,
        Callback = function(val) smCfg.FollowUpKey = val end
    })

    autoMoveSec:AddSlider({
        Id = "slot_" .. slotNum .. "_soru_followup_window",
        Title = "Window (ms)",
        Description = "Proximity check window",
        Min = 50,
        Max = 500,
        Default = smCfg.WindowMs,
        Rounding = 0,
        Callback = function(val) smCfg.WindowMs = val end
    })

    autoMoveSec:AddSlider({
        Id = "slot_" .. slotNum .. "_soru_followup_dist",
        Title = "Trigger Distance (Studs)",
        Description = "Max distance to target",
        Min = 5,
        Max = 50,
        Default = smCfg.TriggerDistance,
        Rounding = 0,
        Callback = function(val) smCfg.TriggerDistance = val end
    })
end

setupSlotTab(1, "Slot 1", "sword")
setupSlotTab(2, "Slot 2", "flame")
setupSlotTab(3, "Slot 3", "shield")
setupSlotTab(4, "Slot 4", "sparkles")

-- 4. Soru (R) Tab
local SoruTab = Window:AddTab({ Title = "Soru", Icon = "zap" })
local SoruSec = SoruTab:AddSection("Soru (R) Spam")

SoruSec:AddToggle({
    Id = "soru_enabled",
    Title = "Soru Spam",
    Description = "Always active on all slots & unequipped",
    Default = Config.Soru.Enabled,
    Callback = function(val) Config.Soru.Enabled = val end
})

SoruSec:AddSlider({
    Id = "soru_delay",
    Title = "Spam Delay (ms)",
    Description = "Loop speed for R",
    Min = 5,
    Max = 100,
    Default = Config.Soru.Delay,
    Rounding = 0,
    Callback = function(val) Config.Soru.Delay = val end
})

local AutoMoveSec = SoruTab:AddSection("Default (Unequipped) Follow-up")

AutoMoveSec:AddToggle({
    Id = "move_after_soru_enabled",
    Title = "Auto Move on Proximity",
    Description = "Fires follow-up when unequipped (Slot 0)",
    Default = Config.MoveAfterSoru.Enabled,
    Callback = function(val) Config.MoveAfterSoru.Enabled = val end
})

AutoMoveSec:AddDropdown({
    Id = "move_after_soru_key",
    Title = "Follow-up Key",
    Description = "Move to cast",
    Values = { "Z", "X", "C", "V", "F" },
    Default = Config.MoveAfterSoru.FollowUpKey,
    Callback = function(val) Config.MoveAfterSoru.FollowUpKey = val end
})

AutoMoveSec:AddSlider({
    Id = "move_after_soru_window",
    Title = "Window (ms)",
    Description = "Proximity check window",
    Min = 50,
    Max = 500,
    Default = Config.MoveAfterSoru.WindowMs,
    Rounding = 0,
    Callback = function(val) Config.MoveAfterSoru.WindowMs = val end
})

AutoMoveSec:AddSlider({
    Id = "move_after_soru_dist",
    Title = "Trigger Distance (Studs)",
    Description = "Max distance to enemy",
    Min = 5,
    Max = 50,
    Default = Config.MoveAfterSoru.TriggerDistance,
    Rounding = 0,
    Callback = function(val) Config.MoveAfterSoru.TriggerDistance = val end
})

-- 5. Settings & Config Tab
local SettingsTab = Window:AddTab({ Title = "Settings", Icon = "settings" })
Window:BuildConfigSection(SettingsTab)
Window:BuildInterfaceSection(SettingsTab)

pcall(function()
    Library:LoadAutoloadConfig()
end)

-- ==============================================================================
-- GROUND / AIR CHECK HELPER
-- ==============================================================================

local function isPlayerInAir(char, root)
    if not char then return false end

    local hum = char:FindFirstChildOfClass("Humanoid")
    if hum and hum.FloorMaterial ~= nil then
        local fm = tostring(hum.FloorMaterial)
        if fm:find("Air") then
            return true
        end
        return false
    end

    if root then
        local vel = root.AssemblyLinearVelocity or root.Velocity
        if vel and math.abs(vel.Y) > 1.2 then
            return true
        end
    end

    return false
end

-- ==============================================================================
-- VELOCITY BOOST DISPATCHER (MOVES, DASH Q, JUMP SPACE)
-- ==============================================================================

-- Direct Velocity Setting for Dash (Q)
local function applyDashBoost()
    if not Config.Movement.Enabled or not Config.Movement.Dash.Enabled then return end

    local now = tick()
    local cd = math.max(0.3, (Config.Movement.Dash.BoostForMs / 1000) + 0.1)
    if (now - (MoveBoostCooldown["q"] or 0)) < cd then
        return
    end
    MoveBoostCooldown["q"] = now

    task.spawn(function()
        if Config.Movement.Dash.BoostAfterMs > 0 then
            task.wait(Config.Movement.Dash.BoostAfterMs / 1000)
        end

        local lp = Players.LocalPlayer
        if not lp or not lp.Character then return end

        local char = lp.Character
        local root = char:FindFirstChild("HumanoidRootPart") or char.PrimaryPart or char:FindFirstChild("Torso")
        if not root then return end

        if Config.Movement.Dash.AirOnly and not isPlayerInAir(char, root) then
            return
        end

        local dir

        -- 1. Check existing horizontal velocity from in-game dash
        local curVel = root.AssemblyLinearVelocity or root.Velocity
        local horizVel = curVel and Vector3.new(curVel.X, 0, curVel.Z)
        if horizVel and horizVel.Magnitude > 3 then
            dir = horizVel.Unit
        end

        -- 2. If velocity hasn't started yet, check physical movement keys (WASD) relative to camera
        if not dir then
            local keyW = iskeypressed(0x57) -- W
            local keyA = iskeypressed(0x41) -- A
            local keyS = iskeypressed(0x53) -- S
            local keyD = iskeypressed(0x44) -- D

            if keyW or keyA or keyS or keyD then
                local inputX = (keyD and 1 or 0) - (keyA and 1 or 0)
                local inputZ = (keyS and 1 or 0) - (keyW and 1 or 0)

                local forward, right
                pcall(function()
                    local cam = workspace.CurrentCamera
                    if cam and cam.CFrame then
                        local cf = cam.CFrame
                        forward = Vector3.new(cf.LookVector.X, 0, cf.LookVector.Z).Unit
                        right = Vector3.new(cf.RightVector.X, 0, cf.RightVector.Z).Unit
                    end
                end)

                if not forward then
                    local rootCF = root.CFrame
                    forward = Vector3.new(rootCF.LookVector.X, 0, rootCF.LookVector.Z).Unit
                    right = Vector3.new(rootCF.RightVector.X, 0, rootCF.RightVector.Z).Unit
                end

                local moveDir = (right * inputX + forward * -inputZ)
                if moveDir.Magnitude > 0.01 then
                    dir = moveDir.Unit
                end
            end
        end

        -- 3. Check Humanoid.MoveDirection
        if not dir then
            local hum = char:FindFirstChildOfClass("Humanoid")
            if hum and hum.MoveDirection and hum.MoveDirection.Magnitude > 0.05 then
                dir = Vector3.new(hum.MoveDirection.X, 0, hum.MoveDirection.Z).Unit
            end
        end

        -- 4. Fallback to character orientation only if completely stationary and no keys pressed
        if not dir then
            local look = root.CFrame.LookVector
            local flatLook = Vector3.new(look.X, 0, look.Z)
            if flatLook.Magnitude > 0.01 then
                dir = flatLook.Unit
            else
                dir = Vector3.new(0, 0, -1)
            end
        end

        local speed = Config.Movement.Dash.Speed or 120
        local duration = math.clamp(Config.Movement.Dash.BoostForMs / 1000, 0.05, 1.0)
        local endTime = tick() + duration

        while tick() < endTime and not Library.Unloaded do
            pcall(function()
                local curY = 0
                if root.AssemblyLinearVelocity ~= nil then
                    curY = root.AssemblyLinearVelocity.Y
                    root.AssemblyLinearVelocity = Vector3.new(dir.X * speed, curY, dir.Z * speed)
                end
                if root.Velocity ~= nil then
                    curY = root.Velocity.Y
                    root.Velocity = Vector3.new(dir.X * speed, curY, dir.Z * speed)
                end
            end)
            task.wait(0.016)
        end
    end)
end

local function applyGenericBoost(actionType, mult, afterMs, forMs, isVertical)
    if not Config.Movement.Enabled then return end
    if not mult or mult == 1.0 then return end

    local now = tick()
    local cd = math.max(0.4, (forMs / 1000) + 0.15)
    if (now - (MoveBoostCooldown[actionType] or 0)) < cd then
        return
    end
    MoveBoostCooldown[actionType] = now

    task.spawn(function()
        if afterMs > 0 then
            task.wait(afterMs / 1000)
        end

        local lp = Players.LocalPlayer
        if not lp or not lp.Character then return end

        local char = lp.Character
        local root = char:FindFirstChild("HumanoidRootPart") or char.PrimaryPart or char:FindFirstChild("Torso")
        if not root then return end

        -- Air-only check (Slot Move Boost respects air-only; Jump naturally initiates in air/ground)
        if actionType ~= "space" and Config.Movement.AirOnly and not isPlayerInAir(char, root) then
            return
        end

        local initialVel = root.AssemblyLinearVelocity or root.Velocity
        if not initialVel then return end

        local targetVel
        if isVertical then
            -- Jump boost: multiplies vertical Y velocity (ensuring a solid base upward boost)
            local yVel = initialVel.Y
            if yVel < 30 then yVel = 50 end
            targetVel = Vector3.new(initialVel.X, yVel * mult, initialVel.Z)
        else
            -- Horizontal move boost
            targetVel = Vector3.new(initialVel.X * mult, initialVel.Y, initialVel.Z * mult)
        end

        local boostDuration = math.clamp(forMs / 1000, 0.05, 1.0)
        local endTime = tick() + boostDuration

        while tick() < endTime and not Library.Unloaded do
            pcall(function()
                if root.AssemblyLinearVelocity ~= nil then root.AssemblyLinearVelocity = targetVel end
                if root.Velocity ~= nil then root.Velocity = targetVel end
            end)
            task.wait(0.016)
        end
    end)
end

-- Slot move boost dispatcher
local LastSlotBoostTime = 0

local function applySlotMoveBoost(keyName)
    local slotNum = Config.CurrentSlot
    if slotNum < 1 or slotNum > 4 then return end

    local sCfg = Config.Movement.Slots[slotNum]
    if not sCfg or not sCfg.Enabled then return end
    if not sCfg.Moves or not sCfg.Moves[keyName] then return end

    local now = tick()
    local cooldownSec = math.max(5.0, sCfg.Cooldown or 5.0)
    if (now - LastSlotBoostTime) < cooldownSec then
        return
    end
    LastSlotBoostTime = now

    applyGenericBoost(keyName, sCfg.Multiplier, sCfg.BoostAfterMs, sCfg.BoostForMs, false)
end

-- ==============================================================================
-- PROXIMITY & ENEMY TARGET DETECTION
-- ==============================================================================

local function getLocalRootPosition()
    local lp = Players.LocalPlayer
    if not lp or not lp.Character then return nil end
    local hrp = lp.Character:FindFirstChild("HumanoidRootPart") or lp.Character.PrimaryPart or lp.Character:FindFirstChild("Torso")
    return (hrp and hrp.Position) or nil
end

local function getClosestTargetDistance()
    local myPos = getLocalRootPosition()
    if not myPos then return 999999 end

    local closest = 999999
    local lp = Players.LocalPlayer

    pcall(function()
        for _, p in ipairs(Players:GetPlayers()) do
            if p ~= lp and p.Character then
                local eHum = p.Character:FindFirstChildOfClass("Humanoid")
                if not eHum or eHum.Health > 0 then
                    local eRoot = p.Character:FindFirstChild("HumanoidRootPart") or p.Character.PrimaryPart or p.Character:FindFirstChild("Torso")
                    if eRoot and eRoot.Position then
                        local dist = (myPos - eRoot.Position).Magnitude
                        if dist < closest then closest = dist end
                    end
                end
            end
        end
    end)

    pcall(function()
        local ws = game:GetService("Workspace")
        local mobs = ws:FindFirstChild("Enemies") or ws:FindFirstChild("NPCs") or ws:FindFirstChild("Characters")
        if mobs then
            for _, mob in ipairs(mobs:GetChildren()) do
                if mob:IsA("Model") and mob ~= (lp and lp.Character) then
                    local mHum = mob:FindFirstChildOfClass("Humanoid")
                    if not mHum or mHum.Health > 0 then
                        local mRoot = mob:FindFirstChild("HumanoidRootPart") or mob.PrimaryPart
                        if mRoot and mRoot.Position then
                            local dist = (myPos - mRoot.Position).Magnitude
                            if dist < closest then closest = dist end
                        end
                    end
                end
            end
        end
    end)

    return closest
end

-- ==============================================================================
-- MOVE AFTER SORU WATCHER
-- ==============================================================================
local LastMoveAfterSoruTrigger = 0

local function getActiveMoveAfterSoruConfig()
    local slotNum = Config.CurrentSlot
    if slotNum >= 1 and slotNum <= 4 then
        local sCfg = Config.Slots[slotNum]
        if sCfg and sCfg.MoveAfterSoru then
            return sCfg.MoveAfterSoru, "Slot " .. slotNum
        end
    end
    return Config.MoveAfterSoru, "Default"
end

local function triggerMoveAfterSoruWatcher()
    local soruCfg, slotName = getActiveMoveAfterSoruConfig()
    if not soruCfg or not soruCfg.Enabled then return end

    local startTime = tick()
    local maxDuration = (soruCfg.WindowMs or 200) / 1000
    local triggerDist = soruCfg.TriggerDistance or 15
    local followKey = soruCfg.FollowUpKey or "Z"
    local cooldownSec = (Config.MoveAfterSoru and Config.MoveAfterSoru.CooldownMs or 400) / 1000

    task.spawn(function()
        while (tick() - startTime) <= maxDuration and not Library.Unloaded do
            local now = tick()
            if (now - LastMoveAfterSoruTrigger) > cooldownSec then
                local dist = getClosestTargetDistance()
                if dist <= triggerDist then
                    LastMoveAfterSoruTrigger = now

                    local keyStr = string.upper(followKey)
                    local targetVK = KeyNameToVK[keyStr] or VK.Z

                    keypress(targetVK)
                    wait(0.03)
                    keyrelease(targetVK)

                    notify("Auto Move (" .. slotName .. ")", "Fired [" .. keyStr .. "] (" .. math.floor(dist) .. " studs)", 1.5)
                    break
                end
            end
            wait(0.01)
        end
    end)
end

-- ==============================================================================
-- DEATH / RESPAWN DETECTION
-- ==============================================================================
task.spawn(function()
    local lastChar = nil
    local wasDead = false

    while not Library.Unloaded do
        pcall(function()
            local lp = Players.LocalPlayer
            if lp and lp.Character then
                local hum = lp.Character:FindFirstChildOfClass("Humanoid")
                if hum then
                    local isDead = (hum.Health <= 0)
                    if isDead and not wasDead then
                        wasDead = true
                        if Config.CurrentSlot ~= 0 then
                            Config.CurrentSlot = 0
                            syncSlotUI(0)
                            notify("Player Died", "Slot reset to None", 2)
                        end
                    elseif not isDead then
                        wasDead = false
                    end
                end

                if lp.Character ~= lastChar then
                    lastChar = lp.Character
                    if Config.CurrentSlot ~= 0 then
                        Config.CurrentSlot = 0
                        syncSlotUI(0)
                        notify("Respawned", "Slot reset to None", 2)
                    end
                end
            end
        end)
        task.wait(0.1)
    end
end)

-- ==============================================================================
-- INPUT & MOVE EXECUTION LOGIC
-- ==============================================================================

local function getActiveSlotRule(key)
    if Config.CurrentSlot >= 1 and Config.CurrentSlot <= 4 then
        local slotCfg = Config.Slots[Config.CurrentSlot]
        if slotCfg.Keys[key] == true then
            return true, slotCfg.Mode or "Spam"
        end
    end
    return false, "Hold"
end

local function handleMoveExecution(keyName, vkCode, mode)
    if ActiveMoveThreads[keyName] then return end
    ActiveMoveThreads[keyName] = true

    task.spawn(function()
        if mode == "Auto-Release" then
            keypress(vkCode)
            wait(Config.AutoReleaseHoldTime / 1000)
            keyrelease(vkCode)

            while iskeypressed(vkCode) and not Library.Unloaded do
                wait(0.01)
            end
        else
            while iskeypressed(vkCode) and Config.Enabled and not Library.Unloaded do
                local isActive, curMode = getActiveSlotRule(keyName)
                if not isActive or curMode ~= "Spam" then break end

                keypress(vkCode)
                wait(Config.ReleaseDelay / 1000)
                keyrelease(vkCode)
                wait(Config.ReleaseDelay / 1000)
            end
            keyrelease(vkCode)
        end

        ActiveMoveThreads[keyName] = false
    end)
end

local function startSoruSpam()
    if ActiveMoveThreads["r"] then return end
    ActiveMoveThreads["r"] = true

    triggerMoveAfterSoruWatcher()

    task.spawn(function()
        while iskeypressed(VK.R) and Config.Enabled and Config.Soru.Enabled and not Library.Unloaded do
            keypress(VK.R)
            wait(Config.Soru.Delay / 1000)
            keyrelease(VK.R)
            wait(Config.Soru.Delay / 1000)
        end
        keyrelease(VK.R)
        ActiveMoveThreads["r"] = false
    end)
end

-- ==============================================================================
-- MAIN INPUT POLLER LOOP
-- ==============================================================================
task.spawn(function()
    print("[Komaru Step] Engine running.")
    notify("Komaru Step Ready", "F1: Toggle | F2: Reset | F3: Menu", 3)

    local moveKeys = {
        { name = "z", vk = VK.Z },
        { name = "x", vk = VK.X },
        { name = "c", vk = VK.C },
        { name = "v", vk = VK.V },
        { name = "f", vk = VK.F },
    }

    local slotKeys = {
        { slot = 1, vk = VK["1"] },
        { slot = 2, vk = VK["2"] },
        { slot = 3, vk = VK["3"] },
        { slot = 4, vk = VK["4"] },
    }

    while not Library.Unloaded do
        -- Check active window without getting blocked
        local active = true
        pcall(function() active = isrbxactive() end)

        if active then
            -- 1. F1 Toggle
            local f1Pressed = iskeypressed(VK.F1)
            if f1Pressed and not PhysicalHeld.F1 then
                PhysicalHeld.F1 = true
                Config.Enabled = not Config.Enabled
                ToggleMain:SetValue(Config.Enabled)
                notify("Macro", Config.Enabled and "ENABLED (F1)" or "DISABLED (F1)", 1.5)
            elseif not f1Pressed then
                PhysicalHeld.F1 = false
            end

            -- 2. F2 Reset Slot
            local f2Pressed = iskeypressed(VK.F2)
            if f2Pressed and not PhysicalHeld.F2 then
                PhysicalHeld.F2 = true
                Config.CurrentSlot = 0
                syncSlotUI(0)
                notify("Reset", "Slot set to None (F2)", 1.5)
            elseif not f2Pressed then
                PhysicalHeld.F2 = false
            end

            -- 3. Dash (Q) Boost Trigger
            local qPressed = iskeypressed(VK.Q)
            if qPressed and not PhysicalHeld.q then
                PhysicalHeld.q = true
                applyDashBoost()
            elseif not qPressed then
                PhysicalHeld.q = false
            end

            -- 4. Jump (Space) Boost Trigger
            local spacePressed = iskeypressed(VK.SPACE)
            if spacePressed and not PhysicalHeld.space then
                PhysicalHeld.space = true
                if Config.Movement.Enabled and Config.Movement.Jump.Enabled then
                    applyGenericBoost("space", Config.Movement.Jump.Multiplier, Config.Movement.Jump.BoostAfterMs, Config.Movement.Jump.BoostForMs, true)
                end
            elseif not spacePressed then
                PhysicalHeld.space = false
            end

            -- 5. Slot Keys 1-4
            if Config.Enabled then
                for _, s in ipairs(slotKeys) do
                    local down = iskeypressed(s.vk)
                    if down and not PhysicalHeld[tostring(s.slot)] then
                        PhysicalHeld[tostring(s.slot)] = true
                        local slotNum = s.slot
                        local cfg = Config.Slots[slotNum]

                        if Config.CurrentSlot == slotNum then
                            if cfg.CanUnequip then
                                Config.CurrentSlot = 0
                                syncSlotUI(0)
                                notify("Unequipped", "Active: None", 1)
                            else
                                notify("Slot Kept", "Unequip blocked", 1)
                            end
                        else
                            Config.CurrentSlot = slotNum
                            syncSlotUI(slotNum)
                            notify("Slot " .. slotNum, "Active: Slot " .. slotNum, 1)
                        end
                    elseif not down then
                        PhysicalHeld[tostring(s.slot)] = false
                    end
                end

                -- 6. Soru Key (R)
                local rDown = iskeypressed(VK.R)
                if rDown then
                    if not PhysicalHeld.r then
                        PhysicalHeld.r = true
                        if Config.Soru.Enabled then
                            startSoruSpam()
                        end
                    end
                else
                    PhysicalHeld.r = false
                end

                -- 7. Move Keys (Z, X, C, V, F)
                for _, m in ipairs(moveKeys) do
                    local down = iskeypressed(m.vk)
                    if down then
                        if not PhysicalHeld[m.name] then
                            PhysicalHeld[m.name] = true

                            -- Slot Move Boost
                            applySlotMoveBoost(m.name)

                            local isFast, mode = getActiveSlotRule(m.name)
                            if isFast then
                                handleMoveExecution(m.name, m.vk, mode)
                            end
                        end
                    else
                        PhysicalHeld[m.name] = false
                    end
                end
            end
        end

        wait(0.005)
    end
end)

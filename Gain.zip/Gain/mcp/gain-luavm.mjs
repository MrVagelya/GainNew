#!/usr/bin/env node
/**
 * Zero-dependency MCP stdio server for Gain LuaVM.
 * Bundled next to Gain.exe in the mcp/ folder.
 */
const baseUrl = (process.env.GAIN_MCP_URL || 'http://127.0.0.1:42424').replace(/\/$/, '')

async function gainFetch(path, options = {}) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 15000)
  try {
    const response = await fetch(`${baseUrl}${path}`, {
      ...options,
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    })
    const text = await response.text()
    try {
      return text ? JSON.parse(text) : {}
    } catch {
      return { ok: false, error: text || `HTTP ${response.status}` }
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    return {
      ok: false,
      error: `Gain bridge unreachable at ${baseUrl} (${message}). Start Gain.exe first.`,
    }
  } finally {
    clearTimeout(timer)
  }
}

const tools = [
  {
    name: 'gain_status',
    description: 'Check if Gain is running and whether Roblox is attached.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'gain_luavm_capabilities',
    description:
      'FULL Gain LuaVM API reference. Call this BEFORE writing any Lua script.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'gain_luavm_rules',
    description: 'Critical DO/DON\'T rules for writing Gain LuaVM scripts.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'gain_luavm_example_esp',
    description: 'Returns a working ESP script for Gain LuaVM.',
    inputSchema: {
      type: 'object',
      properties: {
        minimal: {
          type: 'boolean',
          description: 'If true, return the shortest working ESP.',
        },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'gain_luavm_api',
    description: 'Alias for gain_luavm_capabilities (legacy name).',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'gain_luavm_execute',
    description: 'Run Luau source in Gain LuaVM. Check gain_luavm_console after for errors.',
    inputSchema: {
      type: 'object',
      properties: { source: { type: 'string', description: 'Full Luau script source' } },
      required: ['source'],
      additionalProperties: false,
    },
  },
  {
    name: 'gain_luavm_stop',
    description: 'Stop the currently running LuaVM script.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'gain_luavm_console',
    description: 'Read the LuaVM console output.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'gain_luavm_clear_console',
    description: 'Clear the LuaVM console output.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
]

async function callTool(name, args) {
  if (name === 'gain_status') {
    const health = await gainFetch('/api/health')
    const status = await gainFetch('/api/luavm/status')
    return JSON.stringify({ health, status }, null, 2)
  }
  if (name === 'gain_luavm_capabilities' || name === 'gain_luavm_api') {
    const data = await gainFetch('/api/luavm/api')
    return JSON.stringify(data, null, 2)
  }
  if (name === 'gain_luavm_rules') {
    const data = await gainFetch('/api/luavm/rules')
    return JSON.stringify(data.rules ?? data, null, 2)
  }
  if (name === 'gain_luavm_example_esp') {
    const minimal = Boolean(args?.minimal)
    const path = minimal ? '/api/luavm/example/esp?minimal=true' : '/api/luavm/example/esp'
    const data = await gainFetch(path)
    if (typeof data.source === 'string') return data.source
    return JSON.stringify(data, null, 2)
  }
  if (name === 'gain_luavm_execute') {
    const source = args?.source || ''
    const execute = await gainFetch('/api/luavm/execute', {
      method: 'POST',
      body: JSON.stringify({ source }),
    })
    const status = await gainFetch('/api/luavm/status')
    return JSON.stringify({ execute, status }, null, 2)
  }
  if (name === 'gain_luavm_stop') {
    return JSON.stringify(await gainFetch('/api/luavm/stop', { method: 'POST', body: '{}' }), null, 2)
  }
  if (name === 'gain_luavm_console') {
    const data = await gainFetch('/api/luavm/status')
    return typeof data.console === 'string' && data.console.length ? data.console : '(empty)'
  }
  if (name === 'gain_luavm_clear_console') {
    return JSON.stringify(await gainFetch('/api/luavm/clear', { method: 'POST', body: '{}' }), null, 2)
  }
  throw new Error(`Unknown tool: ${name}`)
}

function send(msg) {
  process.stdout.write(`${JSON.stringify(msg)}\n`)
}

async function handle(msg) {
  const { id, method, params } = msg

  if (method === 'initialize') {
    send({
      jsonrpc: '2.0',
      id,
      result: {
        protocolVersion: params?.protocolVersion || '2024-11-05',
        capabilities: {
          tools: { listChanged: false },
        },
        serverInfo: { name: 'gain-luavm', version: '4.1.0' },
        instructions:
          'Gain LuaVM — external Luau overlay. Call gain_luavm_capabilities and gain_luavm_rules before writing scripts. Gain.exe must be running.',
      },
    })
    return
  }

  if (method === 'notifications/initialized' || method === 'notifications/cancelled') return

  if (method === 'ping') {
    send({ jsonrpc: '2.0', id, result: {} })
    return
  }

  if (method === 'tools/list') {
    send({ jsonrpc: '2.0', id, result: { tools } })
    return
  }

  if (method === 'resources/list') {
    send({ jsonrpc: '2.0', id, result: { resources: [] } })
    return
  }

  if (method === 'resources/templates/list') {
    send({ jsonrpc: '2.0', id, result: { resourceTemplates: [] } })
    return
  }

  if (method === 'prompts/list') {
    send({ jsonrpc: '2.0', id, result: { prompts: [] } })
    return
  }

  if (method === 'logging/setLevel') {
    if (id !== undefined) send({ jsonrpc: '2.0', id, result: {} })
    return
  }

  if (method === 'tools/call') {
    try {
      const text = await callTool(params?.name, params?.arguments || {})
      send({
        jsonrpc: '2.0',
        id,
        result: { content: [{ type: 'text', text }], isError: false },
      })
    } catch (error) {
      send({
        jsonrpc: '2.0',
        id,
        result: {
          content: [{ type: 'text', text: error instanceof Error ? error.message : String(error) }],
          isError: true,
        },
      })
    }
    return
  }

  if (id !== undefined) {
    send({ jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } })
  }
}

let buffer = ''
process.stdin.setEncoding('utf8')
process.stdin.on('data', (chunk) => {
  buffer += chunk
  let idx
  while ((idx = buffer.indexOf('\n')) >= 0) {
    const line = buffer.slice(0, idx).trim()
    buffer = buffer.slice(idx + 1)
    if (!line) continue
    try {
      void handle(JSON.parse(line))
    } catch {
      /* ignore malformed input */
    }
  }
})
